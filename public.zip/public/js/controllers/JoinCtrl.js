angular.module('myapp').controller('JoinController', ['$scope', '$window',function($scope, $window) {
    
}]);