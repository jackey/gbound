angular.module('myapp').controller('AboutController', ['$scope', '$window',function($scope, $window) {

}]);