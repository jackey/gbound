angular.module('myapp').controller('InvestmentController', ['$scope', '$window',function($scope, $window) {
    
}]);