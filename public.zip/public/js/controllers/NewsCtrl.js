angular.module('myapp').controller('NewsController', ['$scope', '$window',function($scope, $window) {

}]);