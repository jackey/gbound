angular.module('NerdService', []).factory('Nerd', ['$http', function($http) {
}]);